<img align="right" src="https://raw.githubusercontent.com/mrmotchy/stuff/main/mr.motchy.gif" height="300" width="300">

# el música

[![Downloads](https://img.shields.io/github/downloads/jagrosh/MusicBot/total.svg)](https://discord.gg/9ZrzNkzeN4)
[![Stars](https://img.shields.io/github/stars/jagrosh/MusicBot.svg)](https://discord.gg/9ZrzNkzeN4)
[![Release](https://img.shields.io/github/release/jagrosh/MusicBot.svg)](https://discord.gg/9ZrzNkzeN4)
[![License](https://img.shields.io/github/license/jagrosh/MusicBot.svg)](https://discord.gg/9ZrzNkzeN4)
[![Discord](https://discordapp.com/api/guilds/147698382092238848/widget.png)](https://discord.gg/9ZrzNkzeN4)<br>
[![CircleCI](https://img.shields.io/circleci/project/github/jagrosh/MusicBot/master.svg)](https://discord.gg/9ZrzNkzeN4)
[![AppVeyor](https://ci.appveyor.com/api/projects/status/gdu6nyte5psj6xfk/branch/master?svg=true)](https://discord.gg/9ZrzNkzeN4)
[![CodeFactor](https://www.codefactor.io/repository/github/jagrosh/musicbot/badge)](https://discord.gg/9ZrzNkzeN4)

[![Setup](http://i.imgur.com/VvXYp5j.png)](https://www.youtube.com/channel/UCmkPzf-eAJsiuCh-5kz4Abw)

## Features
  * Easy to run (just make sure Java is installed, and run!)
  * Fast loading of songs
  * No external keys needed (besides a Discord Bot token)
  * Smooth playback
  * Server-specific setup for the "DJ" role that can moderate the music
  * Clean and beautiful menus
  * Supports many sites, including Youtube, Soundcloud, Spotify and more
  * Supports many online radio/streams
  * Supports local files
  * Playlist support (both web/youtube, and local)
  * custom server prefix

## Personalized server dashboard

![](https://github.com/mrmotchy/stuff/blob/main/222Unbenannt.PNG)
  
  
## High professional discord music bot made with ❤️ and javascript

![](https://github.com/mrmotchy/stuff/blob/main/Unbenannt.PNG)

## Installation


 ### Click [here](https://www.youtube.com/channel/UCmkPzf-eAJsiuCh-5kz4Abw) to watch my YouTube video 


 ### Click here to join my [discord server !](https://dsc.gg/dst74)

![](https://github.com/mrmotchy/stuff/blob/main/Unben111annt.PNG)
